package com.company.domain;

public class Criteria {

}
